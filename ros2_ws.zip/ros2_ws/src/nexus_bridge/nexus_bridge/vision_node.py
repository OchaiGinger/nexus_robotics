# nexus_bridge/vision_node.py
import os
import time
import cv2
import rclpy
from rclpy.node import Node

from nexus_interfaces.srv import DetectObject

try:
    from ultralytics import YOLO
except ImportError as exc:
    raise ImportError(
        "ultralytics not installed — `pip install ultralytics` in the ROS "
        "container/venv this node runs in"
    ) from exc

# Absolute path, in a dedicated folder, so it can be mounted as a volume
# and survive container restarts (see docker-compose.yml's vision_node
# volumes: ./yolo_weights:/ros2_ws/weights). Ultralytics downloads
# directly to this exact path if it's missing, and loads straight from
# it if present — no separate caching logic needed here.
MODEL_WEIGHTS = "/ros2_ws/weights/yolov8n.pt"

# Camera is captured natively on Windows (ffmpeg + DirectShow) and streamed
# in over the network, because usbipd-win's USB passthrough into WSL2 drops
# isochronous video data (confirmed via raw v4l2-ctl capture returning 0
# bytes) even though format negotiation succeeds. Direct /dev/video0
# passthrough is not usable for this camera in this environment.
CAMERA_SOURCE = "http://host.docker.internal:8090"
CAPTURE_DIR = "/ros2_ws/captures"

# Reduce OpenCV/ffmpeg's internal read-ahead buffering to cut latency on
# the MPEG-TS stream (mirrors the -fflags nobuffer we use on the sender).
os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "fflags;nobuffer|flags;low_delay"
def _safe_makedirs(path):
    """os.makedirs(path, exist_ok=True) should never raise if the
    directory already exists — but CAPTURE_DIR is a host folder
    bind-mounted into multiple containers (vision_node, nexus_nodes,
    grid_node), each independently calling this. On WSL2's
    Windows-filesystem bridge, directory-existence checks can lag just
    enough for two containers racing at the same instant to both think
    it's missing, both call mkdir, and one still gets FileExistsError
    despite exist_ok=True. This just treats that race as a non-error."""
    try:
        os.makedirs(path, exist_ok=True)
    except FileExistsError:
        pass
# NOTE: this maps each of our own tool labels to a *set* of stand-in COCO
# classes, because the stock yolov8n.pt weights were never trained on
# "ruler"/"pencil" etc. — these are just visually-similar-shaped classes
# used as placeholders until a fine-tuned model exists (you mentioned
# that's the plan). Original code referenced a singular
# LABEL_TO_COCO_CLASS (no S) that was never defined, which would raise a
# NameError on the first detection request — fixed below by picking a
# single class out of each set. If you actually want "match ANY class in
# the set" rather than "match this one specific class", say so — that's
# a different (small) change to the matching logic further down.
LABEL_TO_COCO_CLASSES = {
    "pen": {"knife", "scissors", "remote"},
    "pencil": {"knife", "scissors", "remote"},
    "ruler": {"toothbrush", "remote"},
}
LABEL_TO_COCO_CLASS = {label: next(iter(classes)) for label, classes in LABEL_TO_COCO_CLASSES.items()}


class YoloNode(Node):
    def __init__(self):
        super().__init__("yolo_node")

        self.cap = cv2.VideoCapture(CAMERA_SOURCE, cv2.CAP_FFMPEG)

        if not self.cap.isOpened():
            self.get_logger().error(f"Could not open camera stream at {CAMERA_SOURCE}")
            raise RuntimeError(f"Could not open camera stream at {CAMERA_SOURCE}")

        self.get_logger().info(f"Camera stream connected at {CAMERA_SOURCE}")

        for _ in range(5):
            self.cap.read()
            time.sleep(0.1)

        self._save_startup_snapshot()

        os.makedirs(os.path.dirname(MODEL_WEIGHTS), exist_ok=True)
        self.model = YOLO(MODEL_WEIGHTS)

        # Warm up the model now, during init (no timeout here), instead of
        # paying the cold-start cost on the first real /vision/detect_object
        # call. The first YOLO inference after loading is much slower than
        # every call after it (thread pool setup, internal init work) —
        # easily several seconds on CPU — which blows straight through
        # pick_tool_node's 3s per-poll timeout and aborts the whole pick
        # action before a warm call ever gets a chance to run.
        ok, warm_frame = self.cap.read()
        if ok:
            self.get_logger().info('warming up YOLO model...')
            warm_start = time.time()
            self.model(warm_frame, verbose=False)
            self.get_logger().info(f'model warm-up took {time.time() - warm_start:.2f}s')
        else:
            self.get_logger().warn('could not read a frame for model warm-up — skipping')

        self.srv = self.create_service(
            DetectObject, "/vision/detect_object", self.handle_detect
        )
        self.get_logger().info("yolo_node ready — serving /vision/detect_object")

    def _save_startup_snapshot(self) -> None:
        ok, frame = self.cap.read()
        if not ok:
            self.get_logger().error("Camera opened but failed to read a test frame")
            return

        self.get_logger().info(
            f"Frame stats: shape={frame.shape} dtype={frame.dtype} "
            f"min={frame.min()} max={frame.max()} mean={frame.mean():.1f}"
        )

        _safe_makedirs(CAPTURE_DIR)
        filename = f"startup_snapshot_{int(time.time())}.jpg"
        path = os.path.join(CAPTURE_DIR, filename)
        cv2.imwrite(path, frame)
        self.get_logger().info(f"Saved startup snapshot to {path}")

    def handle_detect(self, request, response):
        label = request.label
        ok, frame = self.cap.read()
        if not ok:
            self.get_logger().error("Failed to read frame from camera stream")
            response.found = False
            return response

        os.makedirs(CAPTURE_DIR, exist_ok=True)
        debug_path = os.path.join(CAPTURE_DIR, f"detect_{label}_{int(time.time())}.jpg")
        cv2.imwrite(debug_path, frame)
        self.get_logger().info(f"Saved detection frame to {debug_path}")

        results = self.model(frame, verbose=False)[0]

        seen = []
        for box in results.boxes:
            cls_name = self.model.names[int(box.cls[0])]
            conf = float(box.conf[0])
            if conf >= 0.25:
                seen.append(f"{cls_name}({conf:.2f})")
        if seen:
            self.get_logger().info(f"[detect:{label}] saw: {', '.join(seen)}")
        else:
            self.get_logger().info(f"[detect:{label}] saw: nothing above confidence threshold")

        target_class = LABEL_TO_COCO_CLASS.get(label, label)
        best = None
        for box in results.boxes:
            cls_name = self.model.names[int(box.cls[0])]
            if cls_name != target_class:
                continue
            conf = float(box.conf[0])
            if best is None or conf > best["confidence"]:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                best = {
                    "x": (x1 + x2) / 2,
                    "y": (y1 + y2) / 2,
                    "confidence": conf,
                }

        if best is None:
            response.found = False
            return response

        response.found = True
        response.x = best["x"]
        response.y = best["y"]
        response.confidence = best["confidence"]
        return response

    def destroy_node(self):
        self.cap.release()
        super().destroy_node()


def main():
    rclpy.init()
    node = YoloNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()