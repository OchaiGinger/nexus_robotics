# ros2_ws/src/nexus_bridge/nexus_bridge/draw_line_node.py
"""
draw_line_node — implements drawLine, following markPoint's pattern for
landing (steps 2-4 borrowed from mark_point_node), but with a draw step
in place of mark's single "make the mark" move:

  1. grid.get_line(from, to) — validates against paper, also computes
     "vertical"/"horizontal"/"diagonal" for us if orientation wasn't
     given in the goal
  2. motion.move_to("draw_standby") — arbitrary fixed pose so the TOF
     sensor has a stable position to measure from (mirrors mark_point's
     "mark_standby" step; NOT yet XY-aware — see motion_node's
     CONFIG_ANGLES comment)
  3. poll motion.get_distance() until it reaches LAND_THRESHOLD_MM
     (same stop-then-poll pattern as mark_point_node, not concurrent
     move+sense — see the "b" decision precedent in mark_point_node)
  4. motion.move_to("draw_land")
  5. motion.execute_path("draw_line", {...}) — follows a straight path;
     orientation passed through so motion_node can (eventually) choose
     a different joint strategy for vertical vs horizontal, though
     right now it's one placeholder servo move regardless (see
     motion_node's handle_execute_path comment — draw_line still falls
     through to the generic angle=90 branch there)
  6. motion.move_to("ready")
  7. grid.save_snapshot()
  -> success

NOTE: motion_node.py's CONFIG_ANGLES dict needs two new placeholder
entries added before this will run: "draw_standby" and "draw_land".
They're kept distinct from mark_point's "mark_standby"/"mark_land" on
purpose — same kind of arbitrary fixed pose, but for a different tool
action, so tuning one doesn't silently affect the other later.
"""
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from nexus_interfaces.action import DrawLine
from nexus_interfaces.srv import MoveTo, ExecutePath, GetDistance, GetGridLine, SaveTaskSnapshot
from .nexus_common import NexusLogger, call_sync

import json

# Mirrors mark_point_node's LAND_* constants/pattern. Kept as separate
# constants (not imported from mark_point_node) since the two nodes'
# tuning may diverge once real hardware geometry is known.
LAND_THRESHOLD_MM = 20.0
LAND_TIMEOUT_S = 15.0
LAND_POLL_INTERVAL_S = 0.3


class DrawLineNode(Node):
    def __init__(self):
        super().__init__('draw_line_node')
        cb_group = ReentrantCallbackGroup()
        self.log = NexusLogger(self)

        self.move_client = self.create_client(MoveTo, '/motion/move_to', callback_group=cb_group)
        self.execute_path_client = self.create_client(ExecutePath, '/motion/execute_path', callback_group=cb_group)
        self.distance_client = self.create_client(GetDistance, '/motion/get_distance', callback_group=cb_group)
        self.grid_line_client = self.create_client(GetGridLine, '/grid/get_line', callback_group=cb_group)
        self.snapshot_client = self.create_client(SaveTaskSnapshot, '/grid/save_snapshot', callback_group=cb_group)

        self.action_server = ActionServer(
            self, DrawLine, 'draw_line', execute_callback=self.execute, callback_group=cb_group,
        )
        self.log.info('draw_line_node ready — action server on "draw_line"')

    def move_to(self, config_name, x=0.0, y=0.0):
        req = MoveTo.Request(config_name=config_name, x=float(x), y=float(y))
        self.log.doing(f'move_to("{config_name}")')
        result = call_sync(self.move_client, req, timeout_sec=15.0)
        if not result.success:
            raise RuntimeError(f'move_to("{config_name}") failed: {result.message}')
        self.log.sent(f'move_to("{config_name}") -> success')

    def execute(self, goal_handle):
        req = goal_handle.request
        result = DrawLine.Result()
        job_id = f'{int(time.time())}'
        self.log.received(
            f'DrawLine goal: ({req.from_x_mm},{req.from_y_mm}) -> ({req.to_x_mm},{req.to_y_mm}) orientation="{req.orientation}"'
        )

        def step(name):
            goal_handle.publish_feedback(DrawLine.Feedback(current_step=name))
            self.log.doing(f'[drawLine] step: {name}')

        try:
            step('validating_line')
            grid_result = call_sync(self.grid_line_client, GetGridLine.Request(
                from_x_mm=req.from_x_mm, from_y_mm=req.from_y_mm,
                to_x_mm=req.to_x_mm, to_y_mm=req.to_y_mm, label='drawLine',
            ))
            if not grid_result.success:
                raise RuntimeError(f'grid validation failed: {grid_result.message}')
            orientation = req.orientation or grid_result.orientation
            self.log.info(f'orientation resolved to "{orientation}"')

            step('standby')
            self.move_to('draw_standby', x=req.from_x_mm, y=req.from_y_mm)

            step('waiting_for_tof')
            deadline = time.time() + LAND_TIMEOUT_S
            distance = None
            while time.time() < deadline:
                dist_result = call_sync(self.distance_client, GetDistance.Request(), timeout_sec=3.0)
                if dist_result.ok:
                    distance = dist_result.distance_mm
                    self.log.info(f'TOF distance: {distance}mm (threshold {LAND_THRESHOLD_MM}mm)')
                    if distance <= LAND_THRESHOLD_MM:
                        break
                time.sleep(LAND_POLL_INTERVAL_S)
            else:
                raise RuntimeError(f'TOF never reached {LAND_THRESHOLD_MM}mm within {LAND_TIMEOUT_S}s (last={distance})')

            step('landing')
            self.move_to('draw_land', x=req.from_x_mm, y=req.from_y_mm)

            step('drawing')
            params = {
                'from': [req.from_x_mm, req.from_y_mm],
                'to': [req.to_x_mm, req.to_y_mm],
                'orientation': orientation,
            }
            path_result = call_sync(self.execute_path_client, ExecutePath.Request(
                path_type='draw_line', params_json=json.dumps(params),
            ), timeout_sec=15.0)
            if not path_result.success:
                raise RuntimeError(f'execute_path failed: {path_result.message}')

            step('returning_ready')
            self.move_to('ready')

            step('saving_snapshot')
            call_sync(self.snapshot_client, SaveTaskSnapshot.Request(task_id=job_id, task_type='draw_line'))

            step('success')
            result.success = True
            result.message = f'drew {orientation} line'
            goal_handle.succeed()
            return result

        except Exception as exc:  # noqa: BLE001
            self.log.error(f'[drawLine] failed: {exc}')
            result.success = False
            result.message = str(exc)
            goal_handle.abort()
            return result


def main(args=None):
    rclpy.init(args=args)
    node = DrawLineNode()
    executor = MultiThreadedExecutor(num_threads=6)
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()