# ros2_ws/src/nexus_bridge/nexus_bridge/mark_point_node.py
"""
mark_point_node — implements the markPoint sequence as a MarkPoint
action server:

  1. grid.get_point(x_mm, y_mm) — validate against the rectified paper,
     add to the live overlay
  2. motion.move_to("mark_standby") — arbitrary fixed pose so the TOF
     sensor has a stable position to measure from
  3. poll motion.get_distance() until it reaches LAND_THRESHOLD_MM
     (placeholder value — tune once real hardware/geometry exists)
  4. motion.move_to("mark_land")
  5. motion.move_to("mark_config") — actually make the mark
  6. motion.move_to("ready")
  7. grid.save_snapshot()
  -> success

Fail-fast: if the TOF never reaches the threshold within
LAND_TIMEOUT_S, this reports failure rather than looping forever (per
your "b" decision — we'll add retry/backoff later once real hardware
behavior is known).
"""
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from nexus_interfaces.action import MarkPoint
from nexus_interfaces.srv import MoveTo, GetDistance, GetGridPoint, SaveTaskSnapshot
from .nexus_common import NexusLogger, call_sync

LAND_THRESHOLD_MM = 20.0
LAND_TIMEOUT_S = 15.0
LAND_POLL_INTERVAL_S = 0.3


class MarkPointNode(Node):
    def __init__(self):
        super().__init__('mark_point_node')
        cb_group = ReentrantCallbackGroup()
        self.log = NexusLogger(self)

        self.move_client = self.create_client(MoveTo, '/motion/move_to', callback_group=cb_group)
        self.distance_client = self.create_client(GetDistance, '/motion/get_distance', callback_group=cb_group)
        self.grid_point_client = self.create_client(GetGridPoint, '/grid/get_point', callback_group=cb_group)
        self.snapshot_client = self.create_client(SaveTaskSnapshot, '/grid/save_snapshot', callback_group=cb_group)

        self.action_server = ActionServer(
            self, MarkPoint, 'mark_point', execute_callback=self.execute, callback_group=cb_group,
        )
        self.log.info('mark_point_node ready — action server on "mark_point"')

    def move_to(self, config_name, x=0.0, y=0.0):
        req = MoveTo.Request(config_name=config_name, x=float(x), y=float(y))
        self.log.doing(f'move_to("{config_name}")')
        result = call_sync(self.move_client, req, timeout_sec=15.0)
        if not result.success:
            raise RuntimeError(f'move_to("{config_name}") failed: {result.message}')
        self.log.sent(f'move_to("{config_name}") -> success')

    def execute(self, goal_handle):
        x_mm, y_mm = goal_handle.request.x_mm, goal_handle.request.y_mm
        result = MarkPoint.Result()
        job_id = f'{int(time.time())}'
        self.log.received(f'MarkPoint goal: ({x_mm}, {y_mm})')

        def step(name):
            goal_handle.publish_feedback(MarkPoint.Feedback(current_step=name))
            self.log.doing(f'[markPoint] step: {name}')

        try:
            step('validating_point')
            grid_result = call_sync(self.grid_point_client, GetGridPoint.Request(x_mm=x_mm, y_mm=y_mm, label='mark'))
            if not grid_result.success:
                raise RuntimeError(f'grid validation failed: {grid_result.message}')

            step('standby')
            self.move_to('mark_standby')

            step('waiting_for_tof')
            deadline = time.time() + LAND_TIMEOUT_S
            distance = None
            while time.time() < deadline:
                dist_result = call_sync(self.distance_client, GetDistance.Request(), timeout_sec=3.0)
                if dist_result.ok:
                    distance = dist_result.distance_mm
                    self.log.info(f'TOF distance: {distance}mm (threshold {LAND_THRESHOLD_MM}mm)')
                    if distance <= LAND_THRESHOLD_MM:
                        break
                time.sleep(LAND_POLL_INTERVAL_S)
            else:
                raise RuntimeError(f'TOF never reached {LAND_THRESHOLD_MM}mm within {LAND_TIMEOUT_S}s (last={distance})')

            step('landing')
            self.move_to('mark_land')

            step('marking')
            self.move_to('mark_config')

            step('returning_ready')
            self.move_to('ready')

            step('saving_snapshot')
            call_sync(self.snapshot_client, SaveTaskSnapshot.Request(task_id=job_id, task_type='mark_point'))

            step('success')
            result.success = True
            result.message = f'marked point ({x_mm}, {y_mm})'
            goal_handle.succeed()
            return result

        except Exception as exc:  # noqa: BLE001
            self.log.error(f'[markPoint] failed: {exc}')
            result.success = False
            result.message = str(exc)
            goal_handle.abort()
            return result


def main(args=None):
    rclpy.init(args=args)
    node = MarkPointNode()
    executor = MultiThreadedExecutor(num_threads=6)
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
