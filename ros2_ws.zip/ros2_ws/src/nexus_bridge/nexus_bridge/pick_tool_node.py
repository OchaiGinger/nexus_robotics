# ros2_ws/src/nexus_bridge/nexus_bridge/pick_tool_node.py
"""
pick_tool_node — implements the pickTool sequence as a PickTool action
server. Each internal step blocks until the thing it called reports
success before moving to the next one, per spec. Steps:

  1. check tool_state memory:
       - already holding target_object -> skip straight to step 5
       - holding something else -> motion.move_to("drop") then clear
         tool_state (drop location is a fixed stand-in for now)
  2. motion.move_to("calibrate")           # resolve orientation, once
  3. motion.rotate_search(...) + concurrently poll vision.detect_object
     every ~0.4s; whichever returns first wins:
       - vision finds it -> cancel the rotate_search goal
       - rotate_search completes its full sweep on its own -> fail
         (tool never found)
  4. motion.move_to("pick", x, y)          # approach + grip, open-loop
  5. tool_state.set_held_tool(target_object)
  6. motion.move_to("ready")
  -> return success

Grasp confirmation is OPEN-LOOP right now: reaching the "pick" config
without a service error is treated as success. There's no force/current
feedback or vision-confirms-grasp check yet — flagged as a known gap,
add a confirmation step here once that sensor exists.

Search failure path: if nothing is found within one full rotate_search
sweep (see RotateSearch.action's max_angle_deg, currently 360, and its
60s internal safety timeout in motion_node), this action fails with a
clear message rather than hanging forever.
"""
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from nexus_interfaces.action import PickTool, RotateSearch
from nexus_interfaces.srv import MoveTo, GetHeldTool, SetHeldTool, DetectObject, SetScreenState
from .nexus_common import NexusLogger, call_sync, ActionClientCompat

DETECTION_POLL_INTERVAL_S = 0.4
DETECTION_CONFIDENCE_THRESHOLD = 0.25
SEARCH_MAX_ANGLE_DEG = 360.0
STANDARD_DROP_X = 0.0
STANDARD_DROP_Y = 0.0


class PickToolNode(Node):
    def __init__(self):
        super().__init__('pick_tool_node')
        cb_group = ReentrantCallbackGroup()

        self.move_client = self.create_client(MoveTo, '/motion/move_to', callback_group=cb_group)
        self.rotate_client = ActionClientCompat(self, RotateSearch, '/motion/rotate_search', cb_group)
        self.get_held_client = self.create_client(GetHeldTool, '/tool_state/get_held_tool', callback_group=cb_group)
        self.set_held_client = self.create_client(SetHeldTool, '/tool_state/set_held_tool', callback_group=cb_group)
        self.detect_client = self.create_client(DetectObject, '/vision/detect_object', callback_group=cb_group)
        self.screen_client = self.create_client(SetScreenState, '/screen/set_state', callback_group=cb_group)

        self.action_server = ActionServer(
            self,
            PickTool,
            'pick_tool',
            execute_callback=self.execute_pick_tool,
            callback_group=cb_group,
        )

        self.log = NexusLogger(self)
        self.log.info('pick_tool_node ready — action server on "pick_tool"')

    # ---- generic sync-call helper --------------------------------------
    # Pulled into nexus_common.call_sync so every task node shares one
    # implementation; kept as a thin wrapper here so the rest of this
    # file's calls don't all need editing.

    def call_sync(self, client, request, timeout_sec=10.0):
        return call_sync(client, request, timeout_sec=timeout_sec)

    def set_screen(self, state, detail=''):
        try:
            req = SetScreenState.Request()
            req.state = state
            req.detail = detail
            self.call_sync(self.screen_client, req, timeout_sec=3.0)
        except Exception as exc:  # noqa: BLE001 - screen updates must never block the task
            self.log.warn(f'screen update "{state}" failed (continuing): {exc}')

    def move_to(self, config_name, x=0.0, y=0.0):
        req = MoveTo.Request()
        req.config_name = config_name
        req.x = float(x)
        req.y = float(y)
        result = self.call_sync(self.move_client, req, timeout_sec=15.0)
        if not result.success:
            raise RuntimeError(f'move_to("{config_name}") failed: {result.message}')
        return result

    # ---- the state machine ---------------------------------------------

    def execute_pick_tool(self, goal_handle):
        target = goal_handle.request.target_object
        result = PickTool.Result()

        def step(name):
            goal_handle.publish_feedback(PickTool.Feedback(current_step=name))
            self.set_screen(f'picktool_{name}', detail=f'{{"target":"{target}"}}')
            self.log.doing(f'[pickTool:{target}] step: {name}')

        try:
            # Step 1 — check memory
            step('checking_held_tool')
            held = self.call_sync(self.get_held_client, GetHeldTool.Request()).tool

            if held == target:
                self.log.info(f'already holding "{target}" — skipping to ready')
            else:
                if held:
                    step('dropping_previous_tool')
                    self.move_to('drop', STANDARD_DROP_X, STANDARD_DROP_Y)
                    self.call_sync(self.set_held_client, SetHeldTool.Request(tool=''))

                # Step 2 — calibrate
                step('calibrating')
                self.move_to('calibrate')

                # Step 3 — search + concurrent detection poll
                step('searching')
                found = self._search_until_found(target)
                if found is None:
                    result.success = False
                    result.message = f'"{target}" not found after full search rotation'
                    goal_handle.abort()
                    return result

                # Step 4 — approach + grip (open-loop)
                step('picking')
                self.move_to('pick', found['x'], found['y'])

                # Step 5 — update memory
                self.call_sync(self.set_held_client, SetHeldTool.Request(tool=target))

            # Step 6 — return to ready
            step('returning_ready')
            self.move_to('ready')

            step('success')
            result.success = True
            result.message = f'holding "{target}"'
            goal_handle.succeed()
            return result

        except Exception as exc:  # noqa: BLE001 - report any failure cleanly to dispatch_node
            self.log.error(f'[pickTool:{target}] failed: {exc}')
            self.set_screen('picktool_failed', detail=f'{{"target":"{target}","error":"{exc}"}}')
            result.success = False
            result.message = str(exc)
            goal_handle.abort()
            return result

    def _search_until_found(self, target):
        """Starts a RotateSearch goal, polls vision/detect_object while it
        runs, cancels the goal as soon as something's found. Returns the
        detection dict, or None if the sweep completed without a find."""
        goal = RotateSearch.Goal()
        goal.max_angle_deg = SEARCH_MAX_ANGLE_DEG
        handle = self.rotate_client.send_goal(goal)

        try:
            while True:
                if handle.is_result_ready():
                    # Sweep finished on its own without ever being
                    # canceled — treat as "not found".
                    return None

                detect_req = DetectObject.Request()
                detect_req.label = target
                try:
                    detect_result = self.call_sync(self.detect_client, detect_req, timeout_sec=3.0)
                except Exception as exc:  # noqa: BLE001 - one slow/failed poll
                    # shouldn't kill the whole search; keep sweeping and
                    # try again on the next angle instead.
                    self.get_logger().warn(f'detect_object poll failed (continuing search): {exc}')
                    time.sleep(DETECTION_POLL_INTERVAL_S)
                    continue

                if detect_result.found and detect_result.confidence >= DETECTION_CONFIDENCE_THRESHOLD:
                    handle.cancel()
                    return {'x': detect_result.x, 'y': detect_result.y}

                time.sleep(DETECTION_POLL_INTERVAL_S)
        finally:
            handle.wait_until_settled(timeout_sec=5.0)

def main(args=None):
    rclpy.init(args=args)
    node = PickToolNode()
    executor = MultiThreadedExecutor(num_threads=6)
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
