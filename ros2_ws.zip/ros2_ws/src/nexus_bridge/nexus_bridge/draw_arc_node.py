# ros2_ws/src/nexus_bridge/nexus_bridge/draw_arc_node.py
"""
draw_arc_node — implements drawArc. Per your description, the physical
motion only rotates joint 4 by `angle_deg` — radius doesn't drive a
separate axis (no real kinematics/URDF yet), so it's passed through to
grid_node purely so the overlay/screenshot draws the arc at the correct
size, not used by motion_node's actual servo command.

  1. grid.get_point(center) — validate center is on the paper (re-using
     GetGridPoint since there's no dedicated arc-overlay service yet;
     TODO: grid_node could draw the actual arc curve once this is
     confirmed against your log format)
  2. motion.execute_path("draw_arc", {center, radius, angle, direction})
  3. motion.move_to("ready")
  4. grid.save_snapshot()
  -> success
"""
import json
import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor

from nexus_interfaces.action import DrawArc
from nexus_interfaces.srv import MoveTo, ExecutePath, GetGridPoint, SaveTaskSnapshot
from .nexus_common import NexusLogger, call_sync


class DrawArcNode(Node):
    def __init__(self):
        super().__init__('draw_arc_node')
        cb_group = ReentrantCallbackGroup()
        self.log = NexusLogger(self)

        self.move_client = self.create_client(MoveTo, '/motion/move_to', callback_group=cb_group)
        self.execute_path_client = self.create_client(ExecutePath, '/motion/execute_path', callback_group=cb_group)
        self.grid_point_client = self.create_client(GetGridPoint, '/grid/get_point', callback_group=cb_group)
        self.snapshot_client = self.create_client(SaveTaskSnapshot, '/grid/save_snapshot', callback_group=cb_group)

        self.action_server = ActionServer(
            self, DrawArc, 'draw_arc', execute_callback=self.execute, callback_group=cb_group,
        )
        self.log.info('draw_arc_node ready — action server on "draw_arc"')

    def execute(self, goal_handle):
        req = goal_handle.request
        result = DrawArc.Result()
        job_id = f'{int(time.time())}'
        self.log.received(
            f'DrawArc goal: center=({req.center_x_mm},{req.center_y_mm}) radius={req.radius_mm} '
            f'angle={req.angle_deg} direction={req.direction}'
        )

        def step(name):
            goal_handle.publish_feedback(DrawArc.Feedback(current_step=name))
            self.log.doing(f'[drawArc] step: {name}')

        try:
            step('validating_center')
            grid_result = call_sync(self.grid_point_client, GetGridPoint.Request(
                x_mm=req.center_x_mm, y_mm=req.center_y_mm, label='arc_center',
            ))
            if not grid_result.success:
                raise RuntimeError(f'grid validation failed: {grid_result.message}')

            step('drawing_arc')
            params = {
                'center': [req.center_x_mm, req.center_y_mm],
                'radius': req.radius_mm,
                'angle': req.angle_deg,
                'direction': req.direction,
            }
            path_result = call_sync(self.execute_path_client, ExecutePath.Request(
                path_type='draw_arc', params_json=json.dumps(params),
            ), timeout_sec=15.0)
            if not path_result.success:
                raise RuntimeError(f'execute_path failed: {path_result.message}')

            step('returning_ready')
            move_result = call_sync(self.move_client, MoveTo.Request(config_name='ready'), timeout_sec=15.0)
            if not move_result.success:
                raise RuntimeError(f'move_to("ready") failed: {move_result.message}')

            step('saving_snapshot')
            call_sync(self.snapshot_client, SaveTaskSnapshot.Request(task_id=job_id, task_type='draw_arc'))

            step('success')
            result.success = True
            result.message = f'drew {req.angle_deg}deg arc'
            goal_handle.succeed()
            return result

        except Exception as exc:  # noqa: BLE001
            self.log.error(f'[drawArc] failed: {exc}')
            result.success = False
            result.message = str(exc)
            goal_handle.abort()
            return result


def main(args=None):
    rclpy.init(args=args)
    node = DrawArcNode()
    executor = MultiThreadedExecutor(num_threads=6)
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
