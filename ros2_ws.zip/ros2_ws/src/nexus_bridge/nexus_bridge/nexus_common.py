# ros2_ws/src/nexus_bridge/nexus_bridge/nexus_common.py
"""
Shared plumbing used by every node in this package:

  - NexusLogger: wraps a node's normal ROS logger so every log line also
    gets appended to ONE shared file, in real time, from every node/
    process at once — so you can `tail -f` or just open one file and see
    the whole pipeline's activity interleaved in order, instead of
    hunting through per-container `docker compose logs`.

  - call_sync / ActionClientCompat: the same blocking-call helpers
    pick_tool_node.py introduced, pulled out here so every new task node
    (mark_point_node, draw_line_node, draw_arc_node, pick_and_place_node)
    shares one implementation instead of five copies.

Logging format written to the shared file:
    <iso-timestamp> [<node_name>] <LEVEL> <message>

The file is opened fresh (append mode) on every single write rather than
held open, since multiple separate OS processes are writing to it
concurrently — this trades a little performance for not needing any
cross-process locking, which is fine at this log volume.
"""
import os
import time
import datetime

LOG_FILE_PATH = os.environ.get('NEXUS_LOG_FILE', '/ros2_ws/logs/nexus.log')


def _write_log_line(node_name, level, message):
    try:
        os.makedirs(os.path.dirname(LOG_FILE_PATH), exist_ok=True)
        ts = datetime.datetime.now().isoformat(timespec='milliseconds')
        with open(LOG_FILE_PATH, 'a', encoding='utf-8') as f:
            f.write(f'{ts} [{node_name}] {level} {message}\n')
    except Exception:
        pass  # never let logging itself take a node down


class NexusLogger:
    """Use like: self.log = NexusLogger(self); self.log.received(...);
    self.log.doing(...); self.log.sent(...); self.log.error(...)."""

    def __init__(self, node):
        self.node = node
        self.name = node.get_name()
        self._logger = node.get_logger()

    def received(self, message):
        self._logger.info(message)
        _write_log_line(self.name, 'RECEIVED', message)

    def doing(self, message):
        self._logger.info(message)
        _write_log_line(self.name, 'DOING', message)

    def sent(self, message):
        self._logger.info(message)
        _write_log_line(self.name, 'SENT', message)

    def info(self, message):
        self._logger.info(message)
        _write_log_line(self.name, 'INFO', message)

    def warn(self, message):
        self._logger.warning(message)
        _write_log_line(self.name, 'WARN', message)

    def error(self, message):
        self._logger.error(message)
        _write_log_line(self.name, 'ERROR', message)

def call_sync(client, request, timeout_sec=10.0):
    """Blocks the calling thread until a service response lands or the
    timeout hits. Requires the caller's node to run under a
    MultiThreadedExecutor with more than one thread — the response is
    processed on another thread in that pool while this one waits."""
    if not client.wait_for_service(timeout_sec=5.0):
        raise RuntimeError(f'service {client.srv_name} not available')
    future = client.call_async(request)
    deadline = time.time() + timeout_sec
    while not future.done():
        if time.time() > deadline:
            raise RuntimeError(f'timed out waiting for {client.srv_name}')
        time.sleep(0.02)
    return future.result()


class ActionClientCompat:
    """Synchronous-feeling wrapper around rclpy's ActionClient, shared
    across task nodes that call a long-running action (RotateSearch,
    or any future one) and want to block-and-poll rather than juggle
    futures/callbacks inline in their step logic."""

    def __init__(self, node, action_type, action_name, callback_group):
        from rclpy.action import ActionClient
        self.node = node
        self.client = ActionClient(node, action_type, action_name, callback_group=callback_group)

    def send_goal(self, goal_msg):
        if not self.client.wait_for_server(timeout_sec=5.0):
            raise RuntimeError(f'action server {self.client._action_name} not available')
        send_future = self.client.send_goal_async(goal_msg)
        goal_handle = self._spin_until(send_future, timeout_sec=5.0)
        if goal_handle is None or not goal_handle.accepted:
            raise RuntimeError('goal was rejected')
        return _GoalHandleCompat(goal_handle)

    def _spin_until(self, future, timeout_sec):
        deadline = time.time() + timeout_sec
        while not future.done():
            if time.time() > deadline:
                return None
            time.sleep(0.02)
        return future.result()


class _GoalHandleCompat:
    def __init__(self, goal_handle):
        self._goal_handle = goal_handle
        self._result_future = goal_handle.get_result_async()

    def is_result_ready(self):
        return self._result_future.done()

    def cancel(self):
        self._goal_handle.cancel_goal_async()

    def wait_until_settled(self, timeout_sec):
        deadline = time.time() + timeout_sec
        while not self._result_future.done():
            if time.time() > deadline:
                return
            time.sleep(0.02)
