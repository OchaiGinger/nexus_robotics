/*
 * motion_controller.ino
 *
 * Runs on an Arduino Uno. Speaks the line-based text protocol that
 * motion_node.py expects. See PROTOCOL.md alongside this file for the
 * full spec. Real servo control restored (LED test mode removed) now
 * that the serial handshake has been confirmed working end-to-end.
 *
 * Wiring:
 *   MG90S servo: signal -> SERVO_PIN (9), power -> 5V, GND -> GND.
 *   Fine off the Uno's own 5V for single moves and short tests;
 *   switch to an external 5V/1A+ supply before doing sustained
 *   ROTATE_START sweeps, since stall current can brown out the board.
 *   Status LED: anode (through a ~220ohm resistor) -> LED_PIN (8),
 *   cathode -> GND. Lights up alongside every servo move, purely as a
 *   visual "a command was received and acted on" indicator - handy
 *   for confirming activity from across the room without staring at
 *   Serial Monitor.
 *
 * TOF sensor removed for now (hardware issue). GET_TOF still replies
 * to keep the protocol contract intact, but always returns -1
 * ("no sensor"). Harmless since pick_tool_node never calls it.
 */

#include <Servo.h>

#define SERVO_PIN 9
#define LED_PIN 8
#define BAUD_RATE 115200
#define MAX_ANGLE 180
#define MIN_ANGLE 0
#define ROTATE_STEP_DEG 5
#define ROTATE_STEP_DELAY_MS 150

Servo servo;
bool rotating = false;
int currentAngle = 90;
int rotateDirection = 1;
unsigned long lastRotateStepMs = 0;
bool ledState = false;

// ---- TOF placeholder -----------------------------------------------
// Sensor removed for now. Always returns -1 ("no sensor attached").
long readTofMm() {
  return -1;
}

void setup() {
  Serial.begin(BAUD_RATE);
  servo.attach(SERVO_PIN);
  servo.write(currentAngle);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    handleCommand(line);
  }

  if (rotating && millis() - lastRotateStepMs >= ROTATE_STEP_DELAY_MS) {
    lastRotateStepMs = millis();
    currentAngle += rotateDirection * ROTATE_STEP_DEG;
    if (currentAngle >= MAX_ANGLE) {
      currentAngle = MAX_ANGLE;
      rotateDirection = -1;
    } else if (currentAngle <= MIN_ANGLE) {
      currentAngle = MIN_ANGLE;
      rotateDirection = 1;
    }
    servo.write(currentAngle);
    ledState = !ledState;
    digitalWrite(LED_PIN, ledState ? HIGH : LOW);
    Serial.print("ANGLE ");
    Serial.println(currentAngle);
  }
}

void handleCommand(const String &line) {
  if (line.startsWith("SETANGLE")) {
    int angle = line.substring(9).toInt();
    angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
    servo.write(angle);
    currentAngle = angle;
    digitalWrite(LED_PIN, HIGH);
    delay(300); // crude "settle" delay stand-in for real move-complete feedback
    digitalWrite(LED_PIN, LOW);
    Serial.println("OK");

  } else if (line == "ROTATE_START") {
    rotating = true;
    lastRotateStepMs = millis();

  } else if (line == "ROTATE_STOP") {
    rotating = false;
    digitalWrite(LED_PIN, LOW);
    Serial.print("OK ");
    Serial.println(currentAngle);

  } else if (line == "GET_TOF") {
    Serial.print("TOF ");
    Serial.println(readTofMm());
  }
}