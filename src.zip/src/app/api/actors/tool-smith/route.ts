import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

type ToolSmithTaskRecord = { id: string; type: string; payload: unknown };

export async function GET(req: NextRequest) {
  const jobId = req.nextUrl.searchParams.get("jobId");

  if (!jobId) {
    return NextResponse.json(
      { error: "jobId is required" },
      { status: 400 },
    );
  }

  try {
    const tasks = await prisma.task.findMany({
      where: { jobId, status: "pending" },
      orderBy: { createdAt: "asc" },
    });

    const tools: ToolSmithTaskRecord[] = tasks.map((t) => ({
      id: t.id,
      type: t.type,
      payload: t.payload,
    }));

    return NextResponse.json({
      label: "done",
      jobId,
      tools,
    });
  } catch (err) {
    return NextResponse.json(
      {
        error: err instanceof Error ? err.message : "Unknown error",
      },
      { status: 500 },
    );
  }
}
